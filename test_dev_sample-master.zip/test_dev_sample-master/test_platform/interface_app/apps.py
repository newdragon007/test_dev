from django.apps import AppConfig


class InterfaceAppConfig(AppConfig):
    name = 'interface_app'
